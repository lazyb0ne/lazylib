# 图片类型
#
# https://www.lovedan.net/
#
# <a class="hl-item-thumb hl-lazy" href="/voddetail/52374.html" title="斗破苍穹年番" data-original="/upload/vod/20220731-1/d2ccd1bb2fbb0ac0bd842035188563b1.jpg" style="background-image: url(&quot;/upload/vod/20220731-1/d2ccd1bb2fbb0ac0bd842035188563b1.jpg&quot;);">
#     <div class="hl-pic-icon hl-hidden-xs"><i class="iconfont hl-icon-bofang-fill"></i></div>
#         <div class="hl-pic-tag">
#             </div>
#         <div class="hl-pic-text">
#         <span class="hl-lc-1 remarks">更新至43集</span>
#     </div>
#     </a>
#
# https://www.cmvvd.com/
#     <a class="link-hover" href="/vod/8440/" title="海贼王"><img class="lazy" data-original="https://pic1.bdzyimg.com/upload/vod/20230605-1/65aefaa4e756f71e417fb8d89fcdbfd0.webp" src="https://pic1.bdzyimg.com/upload/vod/20230605-1/65aefaa4e756f71e417fb8d89fcdbfd0.webp" alt="海贼王" style="display: inline;"><span class="video-bg"></span><span class="lzbz"><p class="name">海贼王</p><p class="actor">田中真弓,冈村明美,中井和哉,平田广明,山口胜平,山口由里子,大谷育江,土井美加,古川登志夫,草尾毅,大场真人</p><p class="actor">动漫</p><p class="actor">1999/日本</p></span><p class="other"><i>更新至984集</i></p></a>
#
# < a
#
#
# class ="hl-item-thumb hl-lazy" href="/voddetail/71525.html" title="办公室新来的实习生小姐姐活力四射" data-original="/upload/vod/20230704-1/fc4f4d8e6ed4fe55994d4b6cee59b35d.jpg" >