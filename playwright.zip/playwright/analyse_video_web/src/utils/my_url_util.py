import time
from urllib.parse import urlparse, urlunparse

from playwright.sync_api import sync_playwright
from tldextract import tldextract


def test():
    print("OK")


# 去掉字符串两边的引号
def remove_quotes(string):
    try:
        if string.startswith("'") and string.endswith("'"):
            return string[1:-1]
        elif string.startswith('"') and string.endswith('"'):
            return string[1:-1]
        else:
            return string
    except Exception as e:
        return string


# 获取url的主域名
def base_url(url):
    return tldextract.extract(url).registered_domain


def base_url_with_http(url):
    parsed_url = urlparse(url)
    if not parsed_url.scheme or not parsed_url.netloc:
        # 如果URL中没有协议或主机名，则默认为http://
        parsed_url = parsed_url._replace(scheme='http', netloc=url)
    protocol_host = urlunparse((parsed_url.scheme, parsed_url.netloc, '', '', '', ''))
    return protocol_host


def get_page_source_with_playwright(url):
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch()
            page = browser.new_page()
            page.goto(url)
            page.wait_for_load_state('networkidle')
            page_content = page.content()
            browser.close()
        return page_content
    except Exception as e:
        try:
            time.sleep(10);
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch()
                page = browser.new_page()
                page.goto(url)
                page.wait_for_load_state('networkidle')
                page_content = page.content()
                browser.close()
            return page_content
        except Exception as e:
            return None;


def get_source_with_playwright_by_mobile(url):
    # try:
    with sync_playwright() as playwright:
        iphone_12 = playwright.devices['iPhone 12']

        browser = playwright.webkit.launch(headless=False)
        context = browser.new_context(**iphone_12)
        page = context.new_page()

        page.goto(url, timeout=30*1000)
        page.wait_for_load_state('networkidle')

        page_source = page.content()
        print("------------")
        print(page_source)

        page.close()
        context.close()
        browser.close()

        return page_source
    # except Exception as e:
    #     print(f"Error occurred: {str(e)}")
    #     return None;




